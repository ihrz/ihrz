module.exports = {
        name: 'kisakay',
        description: 'What is that?',
        run: async (client, interaction) => {
                return interaction.reply("***yes Kisakay its my owner and good developer. <3***");
        }
}