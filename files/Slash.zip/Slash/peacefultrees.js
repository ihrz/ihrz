module.exports = {
        name: 'peacefultrees',
        description: 'What is that?',
        run: async (client, interaction) => {
      
                return interaction.reply("***yes PeacefulTrees its my owner and good developer. <3***");
                }}