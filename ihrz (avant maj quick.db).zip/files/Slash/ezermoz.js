module.exports = {
        name: 'ezermoz',
        description: 'What is that?',
        run: async (client, interaction) => {
      
                return interaction.reply("***yes Ezermoz its my owner and good developer. <3***");
                }}